# Portofolio - Muhammad Didik Abdurrahman

Repository ini berisi file statis website portofolio sederhana yang menampilkan:
- Profil singkat
- Keahlian (skills)
- Contoh portofolio (motion graphic demo)
- Kontak dan template pesan

## Cara pakai (step-by-step)

1. **Download ZIP** atau clone repository.
2. Jika ingin tes secara lokal, buka `index.html` di browser.
3. Untuk publish via GitHub Pages:
   - Buat repository baru dengan nama `didik24.github.io` (harus persis).
   - Upload seluruh file (index.html, styles.css, script.js, README.md) ke root repo.
   - Commit changes.
   - Buka Settings → Pages → source: `main` branch, folder: `/ (root)`.
   - Tunggu 1-3 menit dan buka: `https://didik24.github.io`

## Ganti kontak & konten
Edit `index.html`:
- Ganti email pada bagian kontak.
- Ganti nomor WhatsApp (ubah link wa.me).
- Ganti tautan Google Drive jika ingin menampilkan video lain.

--- 
Template dibuat rapi, responsif, dan ringan. Kalau mau aku bantu upload dan aktifkan GitHub Pages, beritahu username/akses (atau ikuti panduan dalam README).
